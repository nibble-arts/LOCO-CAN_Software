Arduino-rokkit-hash
===================

Arduino 32-bit hash function.
This is a port of Paul Hsieh's "SuperFastHash" (http://www.azillionmonkeys.com/qed/hash.html).
Great alternative for quick 'n neat CRC/hashing applications, performs 4x faster than classic CRC32.

===================
Distributed under LGPL 2.1 -- http://www.gnu.org/licenses/lgpl-2.1.txt
