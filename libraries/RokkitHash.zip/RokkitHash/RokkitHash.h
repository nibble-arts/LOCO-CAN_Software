#ifndef RokkitHash_h
#define RokkitHash_h

#include <inttypes.h>

uint32_t rokkit(const char * , int );

#endif
