/*
 * LOCO-CAN current class
 * 
 * @author: Thomas H Winkler
 * @copyright: 2020
 * @lizence: GG0
 */

#include <Arduino.h>
#include "measure.h"

MEASURE::MEASURE(void) {
}


/*
 * begin: init port
 */
void MEASURE::begin(uint8_t port) {
    begin(port, -1);
}


void MEASURE::begin(uint8_t port_1, uint8_t port_2) {

    calibrate(1); // set calibration to 1
    setResolution(10); // set to 10 bits as default

    _port_1 = port_1;
    _port_2 = port_2;

    pinMode(port_1, INPUT);

    if (port_2 != -1) {
        pinMode(port_2, INPUT);
    }
}


void MEASURE::begin(uint8_t port_1, uint16_t res, uint16_t cal) {

    begin(port_1);

    setResolution(res);
    calibrate(cal);
}


void MEASURE::begin(uint8_t port_1, uint8_t port_2, uint16_t res, uint16_t cal) {

    begin(port_1, port_2);

    setResolution(res);
    calibrate(cal);
}


// set maximal value
void MEASURE::setResolution(uint8_t bits) {
    _max_val = (1 << bits) - 1;
}


// set calibration
void MEASURE::calibrate(float cal) {
    _cal = cal;
}


// get the absolute value from port 1
uint16_t MEASURE::get(void) {
    return get(MEASURE_VALUE_1);
}


uint16_t MEASURE::get(uint8_t type) {

    switch (type) {
        case MEASURE_VALUE_1:
            return analogRead(_port_1) * _cal;
        break;

        case MEASURE_VALUE_2:
            return analogRead(_port_2) * _cal;
        break;

        case MEASURE_VALUE_RELATIVE:
            uint16_t v0 = 0;
            uint16_t v1;

            v1 = analogRead(_port_1);
            
            // get relative value
            if (_port_2 != -1) {
                v1 = analogRead(_port_2);
            }

            return (v1 - v0) * _cal;
        break;

        // no valid type, get absolut value 1
        default:
            return analogRead(_port_1) * _cal;
        break;
    }
}
